console.log("package.json");
const colors= require('colors');
console.log("sonal shukla ".red);
