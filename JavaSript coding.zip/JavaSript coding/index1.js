//console.log("Hello world");
//var x=10;
//var y=20;
//var z=30;
//console.log(x+y+z);
//var X=20;
/*if(X===20)
{
    console.log("match");
}*/
//var X=20
/* for(i=0;i<10;i++)
{
    console.log(i);
}*/
/*const arr=[2,4,6,8,10]
console.log(arr)
console.log(arr[0])*/
//const app =require('./app')
//console.log(app)
//console.log(app.x)
//console.log(app.y)
//console.log(app)
//console.log(app.z())
/*const arr=[2,3,4,5,67,7,8,9,5];
let result=arr.filter((item)=>{
    //console.log(item)
    //return item===5;
    //return item>3;
    return item>=3;
})
console.warn(result)*/
/*const fs=require('fs')
//console.log("CODE RUN STEP BY STEP");
//fs.writeFileSync("hello.txt",'CODE RAN STEP BY STEP')
fs.writeFileSync("hello1.txt",'Like and Sucribe')*/
/*--core module --*/
//console.log(__dirname);
//console.log("->>",__dirname);
//console.log("->>",__filename);
/*const fs=require('fs')
fs.writeFileSync("code.txt","some code")*/
/*Http Reuest end Resopnse Server Example*/
/*const http= require('http');
const { text } = require('stream/consumers');
//function DataControl(req,resp){
    const DataControl =(req,resp)=>{
    resp.write('<h1>hello  welcome sonal for node js</h1>')
    resp.end();
}
http.createServer(DataControl).listen(4500)


//http.createServer((req,resp)=>{
//resp.write('<h1>hello sonal</h1>')
//resp.end();
//}).listen(4500);*/
/*Pakaage.json*/
console.log("package.json");
/* Step by Step Process  for Package.json in node*/
/*C:\Users\Asus\Desktop\JavaSript coding> npm init
This utility will walk you through creating a package.json file.
It only covers the most common items, and tries to guess sensible defaults.

See `npm help init` for definitive documentation on these fields
and exactly what they do.

Use `npm install <pkg>` afterwards to install a package and
save it as a dependency in the package.json file.

Press ^C at any time to quit.
package name: (javasript-coding)
version: (1.0.0)
description: a node js tutorial
entry point: (app.js)
test command:
git repository: https://github.com/SONALSHUKLA123
keywords: code step by step
author: sonal shukla
license: (ISC)
About to write to C:\Users\Asus\Desktop\JavaSript coding\package.json:

{
  "name": "javasript-coding",
  "version": "1.0.0",
  "description": "a node js tutorial",
  "main": "app.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "repository": {
    "type": "git",
    "url": "https://github.com/SONALSHUKLA123"
  },
  "keywords": [
    "code",
    "step",
    "by",
    "step"
  ],
  "author": "sonal shukla",
  "license": "ISC"
}


Is this OK? (yes)
PS C:\Users\Asus\Desktop\JavaSript coding>*/  
/*fornode file package npm i color*/

/*PS C:\Users\Asus\Desktop\JavaSript coding> npm i color

added 6 packages, and audited 7 packages in 12s

found 0 vulnerabilities*/
/*PS C:\Users\Asus\Desktop\JavaSript coding> npm i simple-node-logger

added 3 packages, and audited 10 packages in 1m

ifound 0 vulnerabilities*/
//const colors= require("colors");
//console.log("sonal shukla ".red);
console.warn("try nodemon")

