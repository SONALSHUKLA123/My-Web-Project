/*const Data=[
{name:'sonal shukla',email:'sonalpshukla93@gmail.com',contact:'9405932029'},
{name:'dhanashri  shukla',email:'dhanashripshukl99@gmail.com',contact:'86059785667'},
{name:'pradip shukla',email:'pd69@gmail.com',contact:'9763870972'}

]
module.exports=Data;*/
const fs = require('fs');
const path = require('path');
const dirpath  = path.join(_dirname);
console.warn(dirpath);
